﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Game.Models;
using System.IO;

namespace Game
{
    public class MVC
    {
        public static Entity player;
        public class Model
        {
            public static Image playerSheet;
            public Model()
            {
                playerSheet = new Bitmap(Path.Combine(new DirectoryInfo(Directory.GetCurrentDirectory()).Parent.Parent.FullName.ToString(),
                    "Content\\characters\\playerEnlarged++.png"));
                player = new Entity(600, 400,
                    Player.idleFrames,
                    Player.runFrames,
                    Player.attackFrames,
                    Player.deathFrames,
                    playerSheet);
            }
        }
        public class Controller
        {
            public static void KeyPress(object sender, KeyEventArgs e)
            {
                switch (e.KeyCode)
                {
                    case Keys.W:
                        player.dirY = -10;
                        player.isMovingUp = true;
                        break;
                    case Keys.S:
                        player.dirY = 10;
                        player.isMovingDown = true;
                        break;
                    case Keys.A:
                        player.dirX = -10;
                        player.isMovingLeft = true;
                        player.flip = -1;
                        break;
                    case Keys.D:
                        player.dirX = 10;
                        player.isMovingRight = true;
                        player.flip = 1;
                        break;
                    case Keys.Up:
                        if (!player.isAttack)
                        {
                            player.isAttack = true;
                            player.StopEntity();
                            player.SetAnimation(8);
                        }
                        break;
                    case Keys.Down:
                        if (!player.isAttack)
                        {
                            player.isAttack = true;
                            player.StopEntity();
                            player.SetAnimation(6);
                        }
                        break;
                    case Keys.Left:
                        if (!player.isAttack)
                        {
                            player.isAttack = true;
                            player.StopEntity();
                            player.flip = -1;
                            player.SetAnimation(7);
                        }
                        break;
                    case Keys.Right:
                        if (!player.isAttack)
                        {
                            player.isAttack = true;
                            player.StopEntity();
                            player.flip = 1;
                            player.SetAnimation(7);
                        }
                        break;
                }
            }

            public static void KeyUp(object sender, KeyEventArgs e)
            {
                switch (e.KeyCode)
                {
                    case Keys.W:
                        player.dirY = player.isMovingDown ? player.dirY : 0;
                        player.isMovingUp = false;
                        if (!player.IsMoving()) player.SetAnimation(2);
                        break;
                    case Keys.S:
                        player.dirY = player.isMovingUp ? player.dirY : 0;
                        player.isMovingDown = false;
                        if (!player.IsMoving()) player.SetAnimation(0);
                        break;
                    case Keys.A:
                        player.dirX = player.isMovingRight ? player.dirX : 0;
                        player.isMovingLeft = false;
                        if (!player.IsMoving()) player.SetAnimation(1);
                        break;
                    case Keys.D:
                        player.dirX = player.isMovingLeft ? player.dirX : 0;
                        player.isMovingRight = false;
                        if (!player.IsMoving()) player.SetAnimation(1);
                        break;

                }
            }
        }
        public class View
        {
            public static void Paint(object sender, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                player.PlayAnimation(g);
            }
        }
    }

    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            new MVC.Model();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1() { Size = new Size(1200, 800) });
        }
    }
}
