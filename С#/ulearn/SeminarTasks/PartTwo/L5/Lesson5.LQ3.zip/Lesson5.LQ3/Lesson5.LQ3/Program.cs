﻿/*Дан набор строк. Найти все строки, в которых ни одна буква не повторяется больше 2 раз.
*/

using System;
using System.Collections.Generic;
using System.Linq;

namespace Lesson5.LQ3
{
    class Program
    {
        static void Main()
        {
            var s = new string[] { "aabbcc", "abbc", "aaabbcc", "qweasddd", "qqw" };
            LQ3.FilterOut(s).DoAction(x => Console.WriteLine(x));
        }
    }

    static public class LQ3
    {
        static public IEnumerable<string> FilterOut(IEnumerable<string> source)
        {
            return source.Where(s => s.GroupBy(c => c).All(group => group.Count() <= 2));
        }

        static public void DoAction<T>(this IEnumerable<T> source, Action<T> action)
        {
            foreach (var item in source) action(item);
        }
    }
}
